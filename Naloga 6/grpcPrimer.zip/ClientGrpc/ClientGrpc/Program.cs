﻿using System.Net;
using System.Threading.Tasks;
using Grpc.Net.Client;
using Google.Protobuf;
using ClientGrpc;

using static ClientGrpc.Greeter;

// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

var channel = GrpcChannel.ForAddress("http://localhost:5027");

var client = new GreeterClient(channel);

var a = client.SayHello(new HelloRequest { Name = "Marko" });

var b = client.SayHelloManyTimes(new HelloManyTimesRequest { Message = "Sandi" });


var c = client.PovejCas(new PovejCasRequest());


Console.WriteLine(a);

Console.WriteLine(b);

Console.WriteLine(c);
