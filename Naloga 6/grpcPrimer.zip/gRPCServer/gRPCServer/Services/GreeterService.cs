using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using gRPCServer;

namespace gRPCServer.Services
{
    public class GreeterService : Greeter.GreeterBase
    {
        private readonly ILogger<GreeterService> _logger;
        public GreeterService(ILogger<GreeterService> logger)
        {
            _logger = logger;
        }

        public override Task<HelloReply> SayHello(HelloRequest request, ServerCallContext context)
        {
            return Task.FromResult(new HelloReply
            {
                Message = "Hello " + request.Name
            });
        }

        public override Task<PovejCasReply> PovejCas(PovejCasRequest request, ServerCallContext context)
        {
            var povejCasReply = new PovejCasReply();
            povejCasReply.Cas = Timestamp.FromDateTime(DateTime.UtcNow);
            return Task.FromResult(povejCasReply);
        }


        public override Task<HelloManyTimesReply> SayHelloManyTimes(HelloManyTimesRequest request, ServerCallContext context)
        {
            var pozdravi = new List<String>();
            pozdravi.Add(new string("Pozdrav " + request.Message));
            pozdravi.Add(new string("Hello " + request.Message));
            pozdravi.Add(new string("Hola " + request.Message));
            pozdravi.Add(new string("Bonjour " + request.Message));
            pozdravi.Add(new string("Ciao " + request.Message));
            pozdravi.Add(new string("Hallo " + request.Message));
            pozdravi.Add(new string("Hej " + request.Message));

            var reply = new HelloManyTimesReply();
            reply.Message.AddRange(pozdravi);

            return Task.FromResult(reply);
        }

    }
}